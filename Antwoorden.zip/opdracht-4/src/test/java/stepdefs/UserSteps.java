package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import jackson.Login;
import jackson.Page;
import jackson.User;
import sun.rmi.runtime.Log;

import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

public class UserSteps {

    private RequestSpecification request;
    private Response response;

    @Given("my credentials are {string} and {string}")
    public void myCredentialsAreAnd(String email, String password) {
        //Opdracht: Maak gebruik van de Login class het request bericht samen te stellen op basis van een object
        Login login = new Login(email, password);
        request = given().contentType(ContentType.JSON).body(login);
    }

    @Given("I want to retrieve the oldest set of users from the system")
    public void iWantToRetrieveTheOldestSetOfUsersFromTheSystem() {
        request = given().queryParam("page", 1);
    }

    @When("the list of users is retrieved")
    public void theListOfUsersIsRetrieved() {
        response = request.when().get("https://reqres.in/api/users");
    }

    @When("I try to login")
    public void iTryToLogin() {
        response = request.post("https://reqres.in/api/login");
    }

    @Then("the system returns {int} users from a total of {int}")
    public void theSystemReturnsUsersFromATotalOf(int returnedUsers, int totalUsers) {
        Page page = response.as(Page.class);
        List<User> users = page.getUsers();
        assertThat(page.getTotal(), equalTo(totalUsers));
        assertThat(users.size(), equalTo(returnedUsers));
    }

    @And("the returned page number is equal to {int}")
    public void theReturnedPageNumberIsEqualTo(int pageNumber) {
        Page pages = response.as(Page.class);
        assertThat(pages.getPage(), equalTo(pageNumber));
    }

    @Then("the system grants me access")
    public void theSystemGrantsMeAccess() {
        response.then().statusCode(200);
        response.then().body(containsString("token"));
    }

    @Then("user {int} has first name {string} and last name {string}")
    public void userHasFirstNameAndLastName(int id, String firstName, String lastName) {
        User user = getUser(id);
        assertThat(user.getId(), equalTo(id));
        assertThat(user.getFirstName(), equalTo(firstName));
        assertThat(user.getLastName(), equalTo(lastName));
    }

    @And("user {int} has an avatar linking to {string}")
    public void userHasAnAvatarLinkingTo(int id, String avatar) {
        User user = getUser(id);
        assertThat(user.getAvatar(), equalTo(avatar));
    }

    private User getUser(int id) {
        Page page = response.as(Page.class);
        return page.getUsers().get(id - 1);
    }
}
