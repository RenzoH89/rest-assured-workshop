package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.when;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItem;

public class SlideshowSteps {

    private Response response;

    @When("I retrieve information about a slideshow")
    public void iRetrieveInformationAboutASampleSlideshow() {
        response = when().get("https://httpbin.org/json");
    }

    @Then("the author of the slideshow is {string}")
    public void theAuthorOfTheSlideshowIs(String author) {
        response.then().body("slideshow.author", equalTo(author));
    }

    @And("the slideshow contains {int} slides")
    public void theSlideshowContainsSlides(int slides) {
        response.then().body("slideshow.slides.size()", equalTo(slides));
    }

    @Then("the title of the slideshow is {string}")
    public void theTitleOfTheSlideShowIs(String title) {
        //TODO: Schrijf hier de code om het title element uit de JSON te valideren
        response.then().body("slideshow.title", equalTo(title));
    }

    @Then("the statuscode {int} is returned")
    public void theStatuscodeIsReturned(int statusCode) {
        response.then().statusCode(statusCode);

    }

    @And("slide {int} contains title {string}")
    public void slideContainsTitle(int slide, String title) {
        //Array starts with 0, so Slide - 1 contains the slide we are looking for
        slide = slide -1;
        response.then().body("slideshow.slides.title", hasItem(title));
        response.then().body("slideshow.slides[" + slide + "].title", equalTo(title));
    }

    @And("the content-type application json is returned")
    public void theContentTypeApplicationJsonIsReturned() {
        response.then().contentType(ContentType.JSON);
    }
}
