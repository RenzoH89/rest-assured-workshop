package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import org.kohsuke.rngom.parse.host.Base;

import static io.restassured.RestAssured.when;
import static org.hamcrest.CoreMatchers.equalTo;

public class SlideshowSteps {
    BaseSteps data;

    public SlideshowSteps(BaseSteps data){
        this.data = data;
    }

    @When("I retrieve information about a slideshow")
    public void iRetrieveInformationAboutASampleSlideshow() {
        data.response =  when().get("https://httpbin.org/json");
    }

    @Then("the author of the slideshow is {string}")
    public void theAuthorOfTheSlideshowIs(String author) {
        data.response.then().body("slideshow.author", equalTo(author));
    }

    @And("the slideshow contains {int} slides")
    public void theSlideshowContainsSlides(int slides) {
        data.response.then().body("slideshow.slides.size()", equalTo(slides));
    }
}
