package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.CoreMatchers.equalTo;

public class AuthenticationSteps {

    private RequestSpecification request;
    private Response response;

    @Given("my credentials are {string} and {string}")
    public void myCredentialsAreAnd(String username, String password) {
        request = given().auth().basic(username, password);
    }

    @When("I try to log in")
    public void iTryToLogIn() {
        response = request.when().get("https://httpbin.org/basic-auth/user/passwd");
    }

    @Then("the system grants me access")
    public void theSystemGrantsMeAccess() {
        response.then().body("authenticated", equalTo(true));
        response.then().statusCode(200);
    }

    @Then("the system denies me access")
    public void theSystemDeniesMeAccess() {
        response.then().statusCode(401);
    }
}

